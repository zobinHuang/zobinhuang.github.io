---
title: 标题
#date: 2021-01-06 01:00:52
---

<head>
<!--导入样式表-->
<link rel="stylesheet" type="text/css" href="style/index.css">

<!--导入网页脚本-->
<script src="script/index.js"></script>

<!--支持网页公式显示-->    
<script type="text/javascript" src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=AM_HTMLorMML-full"></script>

<!--支持矩阵显示-->
<script type="text/javascript">
  run_maths = function() {
    if (document.querySelector('[class*="cmath"]') !== null) {
      if (typeof (mjax_path)=='undefined') { mjax_path='https://cdn.jsdelivr.net/npm/mathjax@2'; }
      if (typeof (mjax_config)=='undefined') { mjax_config='AM_CHTML'; }
      smjax = document.createElement ('script');
      smjax.setAttribute('src',`${mjax_path}/MathJax.js?config=${mjax_config}`);
      smjax.setAttribute('async',true);
      document.getElementsByTagName('head')[0].appendChild(smjax);
    }
  };
  if (document.readyState === 'loading') {  
    window.addEventListener('DOMContentLoaded', run_maths); 
  } else { 
    run_maths(); 
  }
</script>
</head>

<body onload="load_page()">

<div align="center" class="div_indicate_source">
  <h4>⚠ 转载请注明出处：<font color="red"><i>作者：ZobinHuang，更新日期：Jan.30 2022</i></font></h4>
</div>
<div class="div_licence">
  <br>
  <div align="center">
      <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><img alt="知识共享许可协议" style="border-width:0; margin-left: 20px; margin-right: 20px;" src="https://i.creativecommons.org/l/by-nc-nd/4.0/88x31.png" /></a>
  </div>
  <p>
  &nbsp;&nbsp;&nbsp;&nbsp;本<span xmlns:dct="http://purl.org/dc/terms/" href="http://purl.org/dc/dcmitype/Text" rel="dct:type">作品</span>由 <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName"><b>ZobinHuang</b></span> 采用 <a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/4.0/"><font color="red">知识共享署名-非商业性使用-禁止演绎 4.0 国际许可协议</font></a> 进行许可，在进行使用或分享前请查看权限要求。若发现侵权行为，会采取法律手段维护作者正当合法权益，谢谢配合。
  </p>
</div>
<br>
<div class="div_catalogue">
  <div align="center">
    <h1> 目录 </h1>
    <p>
    <font size="3px">有特定需要的内容直接跳转到相关章节查看即可。</font>
  </div>
  <div class="div_load_catalogue_alert" id="load_catalogue_alert">正在加载目录...</div>
  <div class="div_catalogue_container" id="catalogue_container">
  </div>
</div><br>

<!-- Start your post here -->
<h2 class="title">Section</h2>
<div class="div_learning_post">
  <desp class="title">Desp</desp>

  <h3 class="title">Subsection</h3>
  <desp class="title">Desp</desp>
  <p>
  &nbsp;&nbsp;&nbsp;&nbsp;Cite from <ref>sample</ref>
</div>

<h2 class="title">xxx</h2>
<div class="div_learning_post">
  <p>
  &nbsp;&nbsp;&nbsp;&nbsp;
</div>


<div class="div_ref" id="ref_container"></div>

</body>
<!--引用其它章节-->
<!-- 
<ref></ref> 
-->

<!--引用文献-->
<!-- 
<cite></cite> 
-->

<!--关键词-->
<!-- 
<def></def> 
-->

<!--醒目注意-->
<!-- 
<note></note> 
-->

<!--表格-->
<!--
<table border="1" align="center" bgcolor="#FFFFFF">
  <caption>表格</caption>
  <tr>
    <th>A</th>
    <th>B</th>
    <th>C</th>
  </tr>
  <tr>
    <td>xxx</td>
    <td>xxx</td>
    <td>xxx</td>
  </tr>
</table>
-->

<!--矩阵公式-->
<!--
<div class="cmath" align="center">
  `((1, 0),(1, 0))`
</div><br>
-->

<!--图片-->
<!--
<div align="center">
  <img src="./pic/xxx.png" width=80%>
</div>
-->

<!--正文-->
<!--
<p>
&nbsp;&nbsp;&nbsp;&nbsp;公式：<span>`\overline{A}\overline{B}`</span>
</p>
-->